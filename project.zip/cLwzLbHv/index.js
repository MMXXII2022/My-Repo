let CountEl = document.getElementById("count-el")
let saveEl =  document.getElementById("save-el")
let count = 0

function increment() {
     count = count + 1
     CountEl.textContent = count
}

function save() {
    let countStr = count + " - "
    saveEl.textContent += countStr
    console.log(count)
    count = count - count
    CountEl.textContent = count
    
}



// Document.getElementById("count-el").innerText = 


